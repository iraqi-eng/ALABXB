package com.alabxb.app.core.tools.network

import java.net.Inet4Address
import java.net.InetAddress

object NetworkAddressUtils {
    fun ipv4ToLong(address: String): Long {
        val bytes = InetAddress.getByName(address).address
        require(bytes.size == 4) { "IPv4 address required" }
        return ((bytes[0].toLong() and 0xff) shl 24) or
            ((bytes[1].toLong() and 0xff) shl 16) or
            ((bytes[2].toLong() and 0xff) shl 8) or
            (bytes[3].toLong() and 0xff)
    }

    fun longToIpv4(value: Long): String = listOf(
        (value shr 24) and 0xff,
        (value shr 16) and 0xff,
        (value shr 8) and 0xff,
        value and 0xff
    ).joinToString(".")

    fun prefixToMask(prefix: Int): Long {
        require(prefix in 0..32) { "Invalid IPv4 prefix" }
        if (prefix == 0) return 0L
        return (0xffffffffL shl (32 - prefix)) and 0xffffffffL
    }

    fun snapshot(interfaceName: String, address: String, prefix: Int, gateway: String?): NetworkSnapshot {
        require(InetAddress.getByName(address) is Inet4Address) { "IPv4 address required" }
        val ip = ipv4ToLong(address)
        val mask = prefixToMask(prefix)
        val network = ip and mask
        val broadcast = network or (mask.inv() and 0xffffffffL)
        val total = 1L shl (32 - prefix)
        return NetworkSnapshot(
            interfaceName = interfaceName,
            localAddress = address,
            gatewayAddress = gateway,
            prefixLength = prefix,
            networkAddress = longToIpv4(network),
            broadcastAddress = longToIpv4(broadcast),
            hostCount = if (prefix <= 30) total - 2 else 0
        )
    }

    fun candidateAddresses(snapshot: NetworkSnapshot, maxHosts: Int = 254): List<String> {
        require(snapshot.prefixLength in 16..30) { "Only practical private LAN ranges are supported for automatic discovery" }
        val network = ipv4ToLong(snapshot.networkAddress)
        val broadcast = ipv4ToLong(snapshot.broadcastAddress)
        val first = network + 1
        val last = broadcast - 1
        val count = (last - first + 1).coerceAtLeast(0)
        require(count <= maxHosts) { "LAN is larger than the automatic discovery limit" }
        return (first..last).map(::longToIpv4)
    }
}
