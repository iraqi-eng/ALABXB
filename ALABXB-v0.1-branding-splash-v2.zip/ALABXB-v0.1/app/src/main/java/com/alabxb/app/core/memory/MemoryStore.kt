package com.alabxb.app.core.memory

interface MemoryStore { suspend fun remember(scope: MemoryScope, key: String, value: String); suspend fun recall(scope: MemoryScope, key: String): String? }
enum class MemoryScope { USER, PROJECT, DEVICE, NETWORK, TROUBLESHOOTING }
