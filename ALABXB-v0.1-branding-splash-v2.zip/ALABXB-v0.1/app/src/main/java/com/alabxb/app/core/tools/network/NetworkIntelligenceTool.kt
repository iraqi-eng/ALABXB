package com.alabxb.app.core.tools.network

import android.content.Context
import com.alabxb.app.core.tools.ToolExecutionRequest
import com.alabxb.app.core.tools.ToolExecutionResult
import com.alabxb.app.core.tools.ToolGateway
import kotlinx.coroutines.withContext

class NetworkIntelligenceTool(context: Context) : ToolGateway {
    private val discovery = AndroidNetworkDiscovery(context)

    override suspend fun inspect(
        toolId: String,
        input: Map<String, String>
    ): ToolExecutionResult {
        if (toolId != TOOL_ID) {
            return ToolExecutionResult(false, "Unknown tool: $toolId")
        }
        return runCatching {
            val snapshot = discovery.inspectLocalNetwork()
            ToolExecutionResult(true, formatSnapshot(snapshot), verified = true)
        }.getOrElse { error ->
            ToolExecutionResult(false, error.message ?: "Network inspection failed")
        }
    }

    override suspend fun execute(request: ToolExecutionRequest): ToolExecutionResult {
        if (request.toolId != TOOL_ID) {
            return ToolExecutionResult(false, "Unknown tool: ${request.toolId}")
        }
        if (!request.approvedByUser) {
            return ToolExecutionResult(false, "User approval is required before network discovery")
        }
        return withContext(Dispatchers.IO) {
            runCatching {
                val snapshot = discovery.inspectLocalNetwork()
                val result = discovery.discover(snapshot)
                ToolExecutionResult(true, formatResult(result), verified = true)
            }.getOrElse { error ->
                ToolExecutionResult(false, error.message ?: "Network discovery failed")
            }
        }
    }

    private fun formatSnapshot(snapshot: NetworkSnapshot): String = buildString {
        appendLine("Network: ${snapshot.networkAddress}/${snapshot.prefixLength}")
        appendLine("Local: ${snapshot.localAddress}")
        appendLine("Gateway: ${snapshot.gatewayAddress ?: "unknown"}")
        appendLine("Interface: ${snapshot.interfaceName}")
        appendLine("Hosts: ${snapshot.hostCount}")
    }

    private fun formatResult(result: NetworkScanResult): String = buildString {
        append(formatSnapshot(result.snapshot))
        appendLine("Reachable hosts: ${result.hosts.size}")
        result.hosts.forEach { host ->
            val ports = if (host.detectedPorts.isEmpty()) "none" else host.detectedPorts.joinToString(", ")
            appendLine("- ${host.address} | TCP ports: $ports")
        }
    }

    companion object {
        const val TOOL_ID = "network_intelligence"
    }
}
