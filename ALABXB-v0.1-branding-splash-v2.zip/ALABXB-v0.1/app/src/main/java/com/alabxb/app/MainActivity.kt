package com.alabxb.app

import android.app.Activity
import android.os.Bundle
import android.widget.Toast
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.alabxb.app.core.tools.ToolExecutionRequest
import com.alabxb.app.core.tools.network.NetworkIntelligenceTool
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class MainActivity : Activity() {
    private val uiScope = MainScope()
    private var arabic = true
    private lateinit var title: TextView
    private lateinit var subtitle: TextView
    private lateinit var content: TextView
    private lateinit var languageButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showSplash()
    }

    private fun showSplash() {
        val splash = AlabxbSplashView(this)
        setContentView(splash)
        splash.postDelayed({
            if (!isFinishing) showHome()
        }, 3800L)
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 56, 40, 32)
            setBackgroundColor(Color.WHITE)
        }

        title = TextView(this).apply {
            text = "ALABXB"
            textSize = 32f
            setTextColor(Color.rgb(20, 65, 130))
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(title, matchWrap())

        subtitle = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 8, 0, 28)
        }
        root.addView(subtitle, matchWrap())

        val chat = actionButton("💬  Chat") { showSection("Chat", "AI Gateway is ready. AI provider configuration is the next backend step.") }
        val agents = actionButton("🧠  Agents") { showSection("Agents", "Planner • Network • MikroTik • CCTV • Linux • StrykerOSS • Security") }
        val tools = actionButton("🛠  Tools / Network") { showNetworkTool() }
        val projects = actionButton("📁  Projects") { showSection("Projects", "Your projects and conversations will be stored securely in ALABXB Supabase.") }
        val settings = actionButton("⚙️  Settings") { showSection("Settings", "Language, AI provider, permissions and security settings.") }

        listOf(chat, agents, tools, projects, settings).forEach { root.addView(it, matchWrap(12)) }

        languageButton = actionButton("") { arabic = !arabic; updateLanguage() }
        root.addView(languageButton, matchWrap(20))

        content = TextView(this).apply {
            textSize = 13f
            setPadding(0, 24, 0, 0)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(content, matchWrap())

        setContentView(root)
        updateLanguage()
    }

    private fun showNetworkTool() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 56, 40, 32)
            setBackgroundColor(Color.WHITE)
        }

        root.addView(TextView(this).apply {
            text = "Network Intelligence"
            textSize = 26f
            setTextColor(Color.rgb(20, 65, 130))
            gravity = Gravity.CENTER_HORIZONTAL
        }, matchWrap())

        val status = TextView(this).apply {
            textSize = 15f
            setPadding(0, 24, 0, 24)
            text = if (arabic) "أداة اكتشاف شبكة الهاتف. يبدأ الفحص فقط بعد موافقتك." else "Phone network discovery. Scanning starts only after your approval."
        }
        root.addView(status, matchWrap())

        val scan = actionButton(if (arabic) "🔎 فحص شبكة Wi-Fi" else "🔎 Scan Wi-Fi network") {
            val tool = NetworkIntelligenceTool(this)
            uiScope.launch {
                status.text = if (arabic) "جاري قراءة الشبكة..." else "Inspecting network..."
                val result = tool.inspect(NetworkIntelligenceTool.TOOL_ID, emptyMap())
                if (!result.success) {
                    status.text = result.output
                    return@launch
                }
                status.text = result.output + if (arabic) "\n\nهل تريد بدء اكتشاف الأجهزة؟" else "\n\nStart device discovery?"
            }
        }
        root.addView(scan, matchWrap(8))

        val discover = actionButton(if (arabic) "📡 ابدأ اكتشاف الأجهزة" else "📡 Start device discovery") {
            uiScope.launch {
                status.text = if (arabic) "جاري فحص الشبكة..." else "Scanning network..."
                val tool = NetworkIntelligenceTool(this@MainActivity)
                val result = tool.execute(
                    ToolExecutionRequest(
                        toolId = NetworkIntelligenceTool.TOOL_ID,
                        input = emptyMap(),
                        approvedByUser = true
                    )
                )
                status.text = result.output
                if (!result.success) Toast.makeText(this@MainActivity, result.output, Toast.LENGTH_LONG).show()
            }
        }
        root.addView(discover, matchWrap(8))

        root.addView(actionButton(if (arabic) "رجوع" else "Back") { showHome() }, matchWrap(20))
        setContentView(root)
    }

    private fun showSection(name: String, description: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 56, 40, 32)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(TextView(this).apply {
            text = "ALABXB"
            textSize = 28f
            setTextColor(Color.rgb(20, 65, 130))
            gravity = Gravity.CENTER_HORIZONTAL
        }, matchWrap())
        root.addView(TextView(this).apply {
            text = name
            textSize = 24f
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 28, 0, 18)
        }, matchWrap())
        root.addView(TextView(this).apply {
            text = description
            textSize = 16f
            setPadding(0, 12, 0, 30)
        }, matchWrap())
        root.addView(actionButton(if (arabic) "رجوع" else "Back") { showHome() }, matchWrap())
        setContentView(root)
    }

    private fun updateLanguage() {
        subtitle.text = if (arabic) "ذكاء اصطناعي • Agents • أدوات • شبكات" else "AI • Agents • Tools • Network"
        languageButton.text = if (arabic) "🌐  English" else "🌐  العربية"
        content.text = if (arabic) "ALABXB v0.1 — الأساس الأول" else "ALABXB v0.1 — foundation build"
    }

    override fun onDestroy() {
        uiScope.cancel()
        super.onDestroy()
    }

    private fun actionButton(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        textSize = 15f
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun matchWrap(topMargin: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply { if (topMargin > 0) this.topMargin = topMargin }
}
