package com.alabxb.app.core.security

interface PermissionManager { fun canInspect(permission: Permission): Boolean; fun canExecute(permission: Permission): Boolean }
enum class Permission { READ_NETWORK, RUN_DIAGNOSTICS, READ_PROJECT_FILES, EXECUTE_NETWORK_ACTION, EXECUTE_SYSTEM_ACTION }
