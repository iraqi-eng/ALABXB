package com.alabxb.app.core.tools

interface ToolGateway { suspend fun inspect(toolId: String, input: Map<String, String>): ToolExecutionResult; suspend fun execute(request: ToolExecutionRequest): ToolExecutionResult }
data class ToolExecutionRequest(val toolId: String, val input: Map<String, String>, val approvedByUser: Boolean)
data class ToolExecutionResult(val success: Boolean, val output: String, val verified: Boolean = false)
