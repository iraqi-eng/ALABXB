package com.alabxb.app.core.agents

interface Agent { val id: String; val name: String; suspend fun handle(input: AgentInput): AgentResult }
data class AgentInput(val text: String)
data class AgentResult(val summary: String, val nextSteps: List<String> = emptyList())
