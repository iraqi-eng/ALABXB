package com.alabxb.app.core.ai

interface AiGateway { suspend fun generate(request: AiRequest): AiResponse }
data class AiRequest(val systemContext: String, val userInput: String, val toolResults: List<ToolResult> = emptyList())
data class AiResponse(val text: String, val proposedActions: List<ProposedAction> = emptyList())
data class ToolResult(val toolId: String, val success: Boolean, val output: String)
data class ProposedAction(val toolId: String, val reason: String, val requiresApproval: Boolean = true)
