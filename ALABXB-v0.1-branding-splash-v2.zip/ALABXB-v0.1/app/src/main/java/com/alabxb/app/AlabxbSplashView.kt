package com.alabxb.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Short ALABXB startup visual: globe, network paths, traffic pulses, then AL branding.
 * This is a visual intro only; it does not perform a network scan.
 */
class AlabxbSplashView(context: Context) : View(context) {
    private val startMs = System.currentTimeMillis()
    private val durationMs = 3800L

    private val blue = Color.rgb(18, 111, 220)
    private val cyan = Color.rgb(25, 190, 255)
    private val navy = Color.rgb(17, 48, 92)
    private val alert = Color.rgb(235, 76, 76)

    private val globePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.2f
    }
    private val nodePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val pathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.6f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD)
        textAlign = Paint.Align.CENTER
    }
    private val progressPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        strokeCap = Paint.Cap.ROUND
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val elapsed = System.currentTimeMillis() - startMs
        val t = (elapsed.toFloat() / durationMs).coerceIn(0f, 1f)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h * 0.43f
        val radius = min(w, h) * 0.25f

        canvas.drawColor(Color.WHITE)

        // Soft technical halo.
        val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 1.2f
            color = Color.argb((35 + 30 * t).toInt(), 30, 150, 235)
        }
        canvas.drawCircle(cx, cy, radius * 1.22f, halo)
        canvas.drawCircle(cx, cy, radius * 1.38f, halo)

        // Globe.
        globePaint.color = Color.argb((120 + 110 * t).toInt(), 25, 140, 235)
        canvas.drawCircle(cx, cy, radius, globePaint)
        for (i in -2..2) {
            val y = cy + i * radius * 0.22f
            val rx = radius * (1f - kotlin.math.abs(i) * 0.16f)
            canvas.drawOval(cx - rx, y - radius * 0.09f, cx + rx, y + radius * 0.09f, globePaint)
        }
        for (i in -2..2) {
            val x = cx + i * radius * 0.25f
            val ry = radius * (1f - kotlin.math.abs(i) * 0.12f)
            canvas.drawOval(x - radius * 0.09f, cy - ry, x + radius * 0.09f, cy + ry, globePaint)
        }

        // Moving network paths and traffic pulses.
        val phase = elapsed / 850f
        for (i in 0 until 10) {
            val a = i * (Math.PI * 2.0 / 10.0)
            val sx = cx + cos(a).toFloat() * radius * 0.72f
            val sy = cy + sin(a).toFloat() * radius * 0.72f
            val ex = cx + cos(a + 0.85).toFloat() * radius * 1.55f
            val ey = cy + sin(a + 0.85).toFloat() * radius * 1.55f
            pathPaint.color = if (i % 4 == 0) Color.argb(150, 230, 82, 82) else Color.argb(125, 35, 150, 240)
            val path = Path().apply {
                moveTo(sx, sy)
                quadTo(cx + cos(a + 0.42).toFloat() * radius * 1.55f,
                    cy + sin(a + 0.42).toFloat() * radius * 1.55f, ex, ey)
            }
            canvas.drawPath(path, pathPaint)

            val p = ((phase + i * 0.73f) % 1f)
            val px = sx + (ex - sx) * p
            val py = sy + (ey - sy) * p
            nodePaint.color = if (i % 4 == 0) alert else cyan
            canvas.drawCircle(px, py, 4.2f + 2f * sin(elapsed / 180f + i).toFloat().coerceAtLeast(0f), nodePaint)
        }

        // Outer network nodes.
        for (i in 0 until 16) {
            val a = i * (Math.PI * 2.0 / 16.0) + phase * 0.08
            val rr = radius * (1.48f + (i % 3) * 0.08f)
            nodePaint.color = if (i % 5 == 0) alert else blue
            canvas.drawCircle(cx + cos(a).toFloat() * rr, cy + sin(a).toFloat() * rr, 3.3f, nodePaint)
        }

        // AL appears toward the end of the sequence.
        val logoStart = ((t - 0.52f) / 0.25f).coerceIn(0f, 1f)
        textPaint.textSize = radius * 0.72f
        textPaint.shader = LinearGradient(
            cx - radius, cy - radius, cx + radius, cy + radius,
            intArrayOf(navy, blue, cyan), null, Shader.TileMode.CLAMP
        )
        textPaint.alpha = (255 * logoStart).toInt()
        canvas.drawText("AL", cx, cy + radius * 0.26f, textPaint)
        textPaint.shader = null
        textPaint.alpha = 255

        val nameAlpha = ((t - 0.7f) / 0.18f).coerceIn(0f, 1f)
        textPaint.textSize = 18f
        textPaint.color = Color.argb((210 * nameAlpha).toInt(), 20, 60, 110)
        canvas.drawText("ALABXB", cx, cy + radius * 0.62f, textPaint)

        // Startup progress.
        val barY = h * 0.86f
        progressPaint.color = Color.rgb(215, 225, 235)
        canvas.drawLine(w * 0.22f, barY, w * 0.78f, barY, progressPaint)
        progressPaint.color = blue
        canvas.drawLine(w * 0.22f, barY, w * (0.22f + 0.56f * t), barY, progressPaint)

        if (t < 1f) postInvalidateDelayed(16L)
    }
}
