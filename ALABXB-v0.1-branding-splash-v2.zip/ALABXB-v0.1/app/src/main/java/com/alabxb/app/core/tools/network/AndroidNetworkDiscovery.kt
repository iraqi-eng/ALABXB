package com.alabxb.app.core.tools.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.Socket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.withContext

class AndroidNetworkDiscovery(private val context: Context) {
    private val connectivityManager = context.getSystemService(ConnectivityManager::class.java)

    suspend fun inspectLocalNetwork(): NetworkSnapshot = withContext(Dispatchers.IO) {
        val network = connectivityManager.activeNetwork
            ?: error("No active network connection")
        val capabilities = connectivityManager.getNetworkCapabilities(network)
            ?: error("Network capabilities unavailable")
        require(capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            "Wi-Fi connection is required for local network discovery"
        }
        val linkProperties = connectivityManager.getLinkProperties(network)
            ?: error("Network details unavailable")

        val link = linkProperties.linkAddresses.firstOrNull { it.address is Inet4Address }
            ?: error("No IPv4 address found")
        val address = link.address.hostAddress ?: error("IPv4 address unavailable")
        val gateway = linkProperties.routes
            .firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
            ?.gateway?.hostAddress

        NetworkAddressUtils.snapshot(
            interfaceName = linkProperties.interfaceName ?: "unknown",
            address = address,
            prefix = link.prefixLength,
            gateway = gateway
        )
    }

    suspend fun discover(snapshot: NetworkSnapshot): NetworkScanResult = withContext(Dispatchers.IO) {
        val candidates = NetworkAddressUtils.candidateAddresses(snapshot)
        val hosts = candidates.map { address ->
            async(Dispatchers.IO) { probe(address) }
        }.awaitAll().filter { it.reachable }
        NetworkScanResult(snapshot, hosts)
    }

    private fun probe(address: String): NetworkHost {
        val ports = listOf(80, 443, 554, 8080, 8000, 8899)
        val openPorts = ports.filter { port ->
            runCatching {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(address, port), 250)
                    true
                }
            }.getOrDefault(false)
        }
        return NetworkHost(address, openPorts.isNotEmpty(), openPorts)
    }
}
