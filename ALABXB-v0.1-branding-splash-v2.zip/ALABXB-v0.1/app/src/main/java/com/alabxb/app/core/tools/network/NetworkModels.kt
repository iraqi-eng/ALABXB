package com.alabxb.app.core.tools.network

data class NetworkSnapshot(
    val interfaceName: String,
    val localAddress: String,
    val gatewayAddress: String?,
    val prefixLength: Int,
    val networkAddress: String,
    val broadcastAddress: String,
    val hostCount: Long
)

data class NetworkHost(
    val address: String,
    val reachable: Boolean,
    val detectedPorts: List<Int> = emptyList()
)

data class NetworkScanResult(
    val snapshot: NetworkSnapshot,
    val hosts: List<NetworkHost>
)
