package com.alabxb.app.core.workflows

interface Workflow { val id: String; suspend fun run(input: String): WorkflowResult }
data class WorkflowResult(val success: Boolean, val summary: String)
