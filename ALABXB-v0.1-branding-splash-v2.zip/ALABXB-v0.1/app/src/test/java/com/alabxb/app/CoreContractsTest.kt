package com.alabxb.app

import com.alabxb.app.core.security.Permission
import org.junit.Assert.assertEquals
import org.junit.Test

class CoreContractsTest {
    @Test fun permissionNamesRemainStable() {
        assertEquals("READ_NETWORK", Permission.READ_NETWORK.name)
        assertEquals("EXECUTE_NETWORK_ACTION", Permission.EXECUTE_NETWORK_ACTION.name)
    }
}
