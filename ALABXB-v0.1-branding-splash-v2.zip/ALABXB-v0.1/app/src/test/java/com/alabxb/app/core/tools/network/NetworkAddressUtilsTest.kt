package com.alabxb.app.core.tools.network

import org.junit.Assert.assertEquals
import org.junit.Test

class NetworkAddressUtilsTest {
    @Test
    fun calculatesNetworkAndBroadcastFor24() {
        val snapshot = NetworkAddressUtils.snapshot("wlan0", "192.168.1.25", 24, "192.168.1.1")
        assertEquals("192.168.1.0", snapshot.networkAddress)
        assertEquals("192.168.1.255", snapshot.broadcastAddress)
        assertEquals(254L, snapshot.hostCount)
    }

    @Test
    fun generatesUsableHostsFor30() {
        val snapshot = NetworkAddressUtils.snapshot("wlan0", "192.168.10.2", 30, "192.168.10.1")
        assertEquals(listOf("192.168.10.1", "192.168.10.2"), NetworkAddressUtils.candidateAddresses(snapshot))
    }
}
