# ALABXB Network Intelligence — Phase 1

## Purpose

Network Intelligence is a native ALABXB tool for discovering the Wi-Fi network that the Android phone is currently connected to and producing a small, explainable inventory of reachable hosts.

## Current flow

```text
Android Wi-Fi
   -> Network inspection
   -> Local IPv4 + prefix + default gateway
   -> Candidate host addresses
   -> Limited TCP connectivity probes
   -> NetworkScanResult
   -> ALABXB AI (future analysis layer)
```

## Safety boundary

- The tool only derives its scan range from the phone's active Wi-Fi connection.
- Device discovery requires an explicit user action in the current UI.
- Automatic discovery is limited to IPv4 prefixes from /16 through /30 and at most 254 candidate hosts.
- The first implementation probes a small set of common TCP service ports: 80, 443, 554, 8080, 8000, 8899.
- It does not claim that an open port identifies a device type.
- It does not claim a cable fault, data leak, or security incident from connectivity alone.

## Next phases

1. Device fingerprinting with confidence levels.
2. Topology modeling and user-supplied upstream devices (router/radio/DVR/etc.).
3. Evidence-based diagnostics: packet loss, DNS, gateway reachability, link/interface errors where the device exposes them.
4. Optional device protocols such as SNMP/ONVIF/API integrations with explicit authorization.
5. AI interpretation and recommended next tests.
6. Monitoring and historical comparison.

## Project identity

Project creator: **iraqi-eng**. Network Intelligence is an ALABXB-native capability, not a separate application.
