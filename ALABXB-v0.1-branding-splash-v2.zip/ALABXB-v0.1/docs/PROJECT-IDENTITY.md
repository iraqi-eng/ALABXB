# ALABXB Project Identity

- Project name: **ALABXB**
- Project creator: **iraqi-eng**
- External monogram: **AL**
- Launcher icon: white background with the AL monogram and network-orbit mark.
- Startup visual: short 3.8-second network/globe intro shown only when the application opens.

This identity is the branding and documentation reference for the project.
