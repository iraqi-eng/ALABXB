# ALABXB v0.1 Architecture

```text
Android UI -> ALABXB Core
                +-> AI Gateway
                +-> Orchestrator (next phase)
                +-> Agents -> Skills -> Workflows
                +-> Tool Gateway
                +-> Memory
                +-> Security / Permissions
```

Sensitive operations: READ -> ANALYZE -> PROPOSE -> USER APPROVAL -> EXECUTE -> VERIFY

ECC is an engineering reference; ECC source is not copied into ALABXB.

## Project identity

Project creator: **iraqi-eng**. Product identity is **ALABXB**; the external launcher mark is the **AL** monogram.
