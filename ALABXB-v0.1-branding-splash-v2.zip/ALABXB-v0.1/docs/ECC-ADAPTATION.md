# ECC -> ALABXB Adaptation

Source-derived ECC principles: Agent-First, Plan Before Execute, Test-Driven, Security-First, Review/Verify.

ALABXB-specific: Android-first client, provider-neutral AI Gateway, Network/MikroTik/CCTV/Linux/StrykerOSS specializations, explicit approval boundary, and project/device/network memory scopes.

## Project identity

Project creator: **iraqi-eng**.
